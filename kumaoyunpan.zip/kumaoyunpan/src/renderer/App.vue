<template>
  <div id="app">
    <!-- 组件渲染出口 -->
    <router-view></router-view>
  </div>
</template>

<style >
  body {
    font-family: "宋体";
    background-color:#696969;
    font-size:30px;
  }
</style>

