<template>
  <div>
    <iframe src="https://www.weiyun.com/" frameborder="0" width="100%" height="1200px"></iframe>
  </div>
</template>

<script>
export default {
  mounted() {
    document.title = "酷猫云盘管理器";
  }
};
</script>