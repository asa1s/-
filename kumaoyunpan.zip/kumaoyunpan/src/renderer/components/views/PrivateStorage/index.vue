<template>
  <div>
    <iframe src="https://cloud.seafile.com/"  frameborder="0" height="1200px" width="100%"></iframe>
  </div>
</template>

<script>
export default {
  mounted() {
    document.title = "酷猫云盘管理器";
  }
}
</script>

