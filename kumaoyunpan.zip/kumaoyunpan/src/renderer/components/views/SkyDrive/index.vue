<template>
  <div>
      <iframe src="https://v2.fangcloud.com/apps/files/desktop/files/dept/672611" frameborder="0" width="100%" height="1200px"></iframe>
  </div>
</template>

<script>
export default {
  mounted() {
    document.title = "酷猫云盘管理器";
  }
}
</script>